export const IONICONS ={

    backArror: "arrow-back-outline",
    threeDot: "ellipsis-horizontal-outline",
    calander: "calendar-outline",
    image: "image-outline",
    navIcon: "list-outline",
    dropDown: "caret-down-outline",
    upward: "caret-up-outline",
    analytics: "analytics-outline",
    location: "location-sharp",
    bulb: "bulb-sharp",
    backarrow: 'arrow-back-sharp',
    setting: 'settings-outline',
    thumb: 'thumbs-up-sharp',
    message: 'chatbubble-ellipses-sharp',
    send: 'send-sharp',
    close: 'close-circle',
    mail: 'mail-sharp'

  };
  

const ICONS = { IONICONS };

export default ICONS;