export const profile = require("../assets/images/profile.jpg")

export default {
    profile,
 }
