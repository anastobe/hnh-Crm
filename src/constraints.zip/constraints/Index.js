import ICONS from './Icons'
import Images from './Images'
import theme, { COLORS, SIZES, FONTS  } from './Theme'

export { ICONS, Images,theme, COLORS, SIZES, FONTS  }